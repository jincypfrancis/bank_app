
-- --------------------------------------------------------

--
-- Table structure for table `bank_transfer`
--

CREATE TABLE `bank_transfer` (
  `id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `email` varchar(300) NOT NULL,
  `transfered_customer` int(11) NOT NULL,
  `transfered_email` varchar(300) NOT NULL,
  `transdate` date NOT NULL,
  `amount` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_transfer`
--

INSERT INTO `bank_transfer` (`id`, `customerid`, `email`, `transfered_customer`, `transfered_email`, `transdate`, `amount`) VALUES
(3, 11, 'jincytest@cust.com', 12, 'jincytest2@cust.com', '2024-02-22', 100.00),
(4, 11, 'jincytest@cust.com', 12, 'jincytest2@cust.com', '2024-02-22', 300.00),
(5, 11, 'jincytest@cust.com', 12, 'jincytest2@cust.com', '2024-02-22', 10.00),
(6, 12, 'jincytest2@cust.com', 11, 'jincytest@cust.com', '2024-02-22', 100.00);
