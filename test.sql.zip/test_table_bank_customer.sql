
-- --------------------------------------------------------

--
-- Table structure for table `bank_customer`
--

CREATE TABLE `bank_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(300) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `balance` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_customer`
--

INSERT INTO `bank_customer` (`id`, `name`, `email`, `password`, `balance`) VALUES
(11, 'jincy test customer', 'jincytest@cust.com', 'jincy', 689.67),
(12, 'jincy test customer2', 'jincytest2@cust.com', 'jincy', 1210.00);
