
-- --------------------------------------------------------

--
-- Table structure for table `bank_transaction`
--

CREATE TABLE `bank_transaction` (
  `id` int(11) NOT NULL,
  `customerid` int(11) NOT NULL,
  `email` varchar(300) NOT NULL,
  `transactiontype` varchar(300) NOT NULL,
  `type` varchar(10) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `balanceafter` decimal(12,2) NOT NULL,
  `transdate` datetime NOT NULL,
  `remarks` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bank_transaction`
--

INSERT INTO `bank_transaction` (`id`, `customerid`, `email`, `transactiontype`, `type`, `amount`, `balanceafter`, `transdate`, `remarks`) VALUES
(15, 11, 'jincytest@cust.com', 'deposit', 'Credit', 1000.00, 1000.00, '2024-02-22 07:04:18', 'Deposit'),
(16, 11, 'jincytest@cust.com', 'deposit', 'Credit', 2000.00, 3000.00, '2024-02-22 07:06:50', 'Deposit'),
(17, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 1000.00, 2000.00, '2024-02-22 07:07:09', 'Withdraw'),
(18, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 1000.00, 1000.00, '2024-02-22 07:07:32', 'Withdraw'),
(19, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 1000.00, 0.00, '2024-02-22 07:41:37', 'Withdraw'),
(20, 11, 'jincytest@cust.com', 'deposit', 'Credit', 1000.00, 1000.00, '2024-02-22 07:48:54', 'Deposit'),
(21, 11, 'jincytest@cust.com', 'deposit', 'Credit', 10.22, 1010.22, '2024-02-22 07:59:00', 'Deposit'),
(22, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 10.33, 999.89, '2024-02-22 07:59:29', 'Withdraw'),
(25, 11, 'jincytest@cust.com', 'deposit', 'Credit', 10.00, 1009.89, '2024-02-22 08:41:57', 'Deposit'),
(26, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 10.22, 999.67, '2024-02-22 08:49:04', 'Withdraw'),
(27, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 100.00, 899.67, '2024-02-22 08:50:10', 'Transfer To jincytest2@cust.com'),
(28, 12, 'jincytest2@cust.com', 'deposit', 'Credit', 100.00, 100.00, '2024-02-22 08:50:10', 'Transfer From jincytest@cust.com'),
(29, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 300.00, 599.67, '2024-02-22 08:50:28', 'Transfer To jincytest2@cust.com'),
(30, 12, 'jincytest2@cust.com', 'deposit', 'Credit', 300.00, 400.00, '2024-02-22 08:50:28', 'Transfer From jincytest@cust.com'),
(31, 11, 'jincytest@cust.com', 'withdraw', 'Debit', 10.00, 589.67, '2024-02-22 08:52:30', 'Transfer To jincytest2@cust.com'),
(32, 12, 'jincytest2@cust.com', 'deposit', 'Credit', 10.00, 410.00, '2024-02-22 08:52:30', 'Transfer From jincytest@cust.com'),
(33, 12, 'jincytest2@cust.com', 'deposit', 'Credit', 1000.00, 1410.00, '2024-02-22 08:52:56', 'Deposit'),
(34, 12, 'jincytest2@cust.com', 'withdraw', 'Debit', 100.00, 1310.00, '2024-02-22 08:53:07', 'Withdraw'),
(35, 12, 'jincytest2@cust.com', 'withdraw', 'Debit', 100.00, 1210.00, '2024-02-22 08:53:35', 'Transfer To jincytest@cust.com'),
(36, 11, 'jincytest@cust.com', 'deposit', 'Credit', 100.00, 689.67, '2024-02-22 08:53:35', 'Transfer From jincytest2@cust.com');
